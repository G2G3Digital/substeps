Substeps Example Project
========================

This sample substep project uses the webdriver-substep implementations to illustrate how to setup such a project.
It can be built and run using standard maven commands:

mvn clean install

and will run against a static html included with the source.

Feel free to use this as a starting point to create something more appropriate for your project.  